import { useSelector, useDispatch } from "react-redux";
import { changeSearchTerm } from "../store";
import { useNavigate } from "react-router-dom";
import React from "react";
import { RootState } from "../store";

function SearchInstructor() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const searchTerm = useSelector((state: RootState) => state.searchMovie.searchTerm);

  const handleSearchTermChange = (event) => {
    dispatch(changeSearchTerm(event.target.value));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    navigate("/instructors");
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>Search Instructor</label>
      <input className="input ml-2" value={searchTerm} onChange={handleSearchTermChange} />
    </form>
  );
}

export default SearchInstructor;
