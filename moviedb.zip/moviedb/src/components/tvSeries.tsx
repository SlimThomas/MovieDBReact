import { useFetchPopularTVShowsQuery } from "../store/apis/moviesApi";
import MovieCard from "./movieCard";
import React from "react";

function TVSeriesList() {
  const { data, error, isFetching } = useFetchPopularTVShowsQuery();

  let content;

  if (isFetching) {
    content = <div>Loading...</div>;
  } else if (error) {
    content = <div>Error loading TV shows.</div>;
  } else if (data) {
    content = data.map((tvShow) => (
      <MovieCard key={tvShow.id} movie={tvShow} />
    ));
  }

  return (
    <div className="row row-cols-3 row-cols-md-2 m-4">
      {content}
    </div>
  );
}

export default TVSeriesList;
