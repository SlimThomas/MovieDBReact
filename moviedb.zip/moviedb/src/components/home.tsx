import MovieImg from '../assets/Image/movie_black2.jpg';
import React from "react";

function Home() {
    return ( <div>
            <img className="rounded movie_img m-3" src={MovieImg} width="450" height="450"/>



    </div>)



}

export default Home; 