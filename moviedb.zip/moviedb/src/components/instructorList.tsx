import { useSelector } from "react-redux";
import { useSearchInstructorQuery } from "../store/apis/moviesApi";
import React from "react";
import { RootState } from "../store";

function InstructorList() {
  const searchTerm = useSelector((state: RootState) => state.searchMovie.searchTerm);
  const { data = [], error, isFetching } = useSearchInstructorQuery({ name: searchTerm });

  let content;
  if (isFetching) {
    content = <div>Loading...</div>;
  } else if (error) {
    content = <div>Error loading instructors.</div>;
  } else if (data.length === 0) {
    content = <div>No instructors found.</div>;
  } else {
    content = data.map((person) => (
      <div key={person.id} className="card mb-3 p-2">
        <h5>{person.name}</h5>
        <div className="d-flex flex-wrap">
          {person.known_for.map((work) => (
            <div key={work.id} className="me-3">
              <img
                src={`https://image.tmdb.org/t/p/w185${work.poster_path}`}
                alt={work.title || work.name}
                width="100"
              />
              <p className="small">{work.title || work.name}</p>
            </div>
          ))}
        </div>
      </div>
    ));
  }

  return <div className="container">{content}</div>;
}

export default InstructorList;
