import React, { useState } from 'react';
import MovieTrailer from './playMovie';
import {
  useAddFavoriteMovieMutation,
  useRemoveFavoriteMovieMutation,
  useGetFavoriteMoviesQuery,
} from '../store/apis/moviesApi';

function MovieCard({ movie }) {
  const [showTrailer, setShowTrailer] = useState(false);
  const [addFavorite] = useAddFavoriteMovieMutation();
  const [removeFavorite] = useRemoveFavoriteMovieMutation();
  const { data: favorites } = useGetFavoriteMoviesQuery();

  const posterBasePath = 'https://image.tmdb.org/t/p/w185_and_h278_bestv2';

  const isFavorited = favorites?.some((fav) => fav.id === movie.id);

  const handleToggleFavorite = (e) => {
    e.preventDefault();
    e.stopPropagation();
  
    if (!favorites) return;
  
    if (isFavorited) {
      const favoriteToRemove = favorites.find((fav) => fav.id === movie.id);
      if (favoriteToRemove?.id) {
        removeFavorite(favoriteToRemove.id)
          .unwrap()
          .catch((err) => console.error('Failed to remove favorite:', err));
      }
    } else {
      // 💡 Check if the movie is already in favorites by ID
      const alreadyExists = favorites.some((fav) => fav.id === movie.id);
      if (!alreadyExists) {
        addFavorite(movie)
          .unwrap()
          .catch((err) => console.error('Failed to add favorite:', err));
      } else {
        console.log('Duplicate movie — not adding again.');
      }
    }
  };
  

  return (
    <div className="col-lg-2 mb-4">
      <div className="card">
        <img src={posterBasePath + movie.poster_path} className="card-img-top" alt={movie.title} />
        <div className="card-body">
          <h5 className="card-title">
            <span>{movie.title.substring(0, 200)}</span>
          </h5>

          {/* ⭐ Star toggle */}
          <span
            className={isFavorited ? 'fas fa-star text-warning' : 'far fa-star'}
            onClick={handleToggleFavorite}
            style={{ cursor: 'pointer' }}
            aria-hidden="true"
            title={isFavorited ? 'Remove from favorites' : 'Add to favorites'}
            ></span>

          <span className="ml-1">{movie.vote_average}</span>
          <p className="card-text">{movie.overview.substring(0, 125).concat('....')}</p>
          <div className="d-flex justify-content-between p-0">
            <span className="far fa-calendar" aria-hidden="true">
              {' '}
              {movie.release_date}
            </span>
            <span
              className={showTrailer ? 'far fa-times-circle' : 'far fa-play-circle'}
              onClick={() => setShowTrailer(!showTrailer)}
              style={{ cursor: 'pointer' }}
            ></span>
          </div>
        </div>
      </div>
      {showTrailer && <MovieTrailer movieId={movie.id} />}
    </div>
  );
}

export default MovieCard;
