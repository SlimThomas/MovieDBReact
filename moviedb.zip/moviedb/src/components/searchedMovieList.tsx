import { useFetchSearchMovieQuery, useFetchMovieGenresQuery } from "../store";
import MovieCard from "./movieCard";
import { useSelector } from "react-redux";
import React, { useState } from "react";
import { RootState } from "../store";
import GenreSelect from "./genreSelect"; // reuse the dropdown we made

function SearchedMoviesList() {
  const searchTerm = useSelector((state: RootState) => state.searchMovie.searchTerm);
  const { data: genres = [] } = useFetchMovieGenresQuery();
  const { data = [], error, isFetching } = useFetchSearchMovieQuery({ searchTerm });
  const [selectedGenre, setSelectedGenre] = useState("");

  // Filter logic
  const filteredData = selectedGenre
    ? data.filter(
        (movie) =>
          movie.genres.includes(Number(selectedGenre)) && movie.poster_path !== null && movie.vote_average !== 0
      )
    : data.filter((movie) => movie.poster_path !== null && movie.vote_average !== 0);

  let content;
  if (isFetching) {
    content = <div>Loading...</div>;
  } else if (error) {
    content = <div>Error loading movies.</div>;
  } else if (filteredData.length === 0) {
    content = <div>No results found.</div>;
  } else {
    content = filteredData.map((movie) => <MovieCard key={movie.id} movie={movie} />);
  }

  return (
    <div className="container">
      <GenreSelect
        genres={genres}
        selectedGenre={selectedGenre}
        onChange={setSelectedGenre}
        label="Filter by Genre"
      />
      <div className="row row-cols-3 row-cols-md-2 m-4">{content}</div>
    </div>
  );
}

export default SearchedMoviesList;
