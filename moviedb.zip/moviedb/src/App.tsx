import { Routes, Route, Link } from 'react-router-dom';
import HighestRatedMovieList from "./components/highestRatedMoviesList";
import PopularMoviesList from "./components/popularMoviesList";
import MovieImg from './assets/Image/movie_black2.jpg';
import Home from './components/home';
import SearchMovie from './components/searchMovie';
import SearchedMoviesList from './components/searchedMovieList';
import React from "react";
import UpcomingMoviesList from './components/upcomingMoviesList';
import FavoritePage from './components/favoritePage';
import TVSeriesList from './components/tvSeries';
import InstructorList from './components/instructorList';
import SearchInstructor from './components/searchInstructor';

function App() {
  return (
    <div>
      <div className="jumbotron pb-3 pt-3">
        <div className="navbar navbar-expand-lg">
          <nav className="nav navbar-nav">    
            <Link to='/' className="nav-item nav-link">Home</Link>
            <Link to='/popular' className="nav-item nav-link">Popular</Link>
            <Link to='/highest-rated' className="nav-item nav-link">Highest Rated</Link>
            <Link to='/upcomingMovies' className="nav-item nav-link">Upcoming</Link>
            <Link to='/favorite' className="nav-item nav-link">Favorite</Link>
            <Link to='/tvSeries' className="nav-item nav-link">TV Series</Link>
            <Link to='/instructors' className="nav-item nav-link">Instructors</Link>

            
          </nav>
        </div>
          <span className='h1'>React Moviefinder <img className="rounded movie_img m-3" src={MovieImg} width="75" height="75"/></span>
      <span className="d-flex justify-content-between p-0">This small App demonstrates React, Redux-Toolkit, RTK Query and React-Router<SearchMovie></SearchMovie></span>
        </div>
        <Routes>
            <Route path='/' element={<Home/>} />  
            <Route path='/popular' element={<PopularMoviesList/>} />    
            <Route path='/highest-rated' element={<HighestRatedMovieList/>} />
            <Route path='/searchedMovie' element={<SearchedMoviesList/>} />
            <Route path='/upcomingMovies' element={<UpcomingMoviesList/>} />
            <Route path='/favorite' element={<FavoritePage/>} />
            <Route path='/tvSeries' element={<TVSeriesList/>} />
            <Route path='/instructors' element={<InstructorList/>} />
            <Route path='/searchInstructor' element={<SearchInstructor/>} />
        </Routes>
    </div>
  );
} 

export default App;