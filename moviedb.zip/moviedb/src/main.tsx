import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { Provider } from 'react-redux';
import { store } from './store'; // Importér din store
import { BrowserRouter } from 'react-router-dom';

const el = document.getElementById('root');


if (!el) {
  throw new Error('Root element not found');
}

createRoot(el).render(
    <Provider store={store}>
    <BrowserRouter> 
      <App />
    </BrowserRouter>
  </Provider>
);