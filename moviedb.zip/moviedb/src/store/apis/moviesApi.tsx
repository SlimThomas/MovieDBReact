import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { Movie, MovieResults } from '../types/movies';

const moviesApi = createApi({
  reducerPath: 'movies',
  baseQuery: fetchBaseQuery({
    baseUrl: 'http://api.themoviedb.org/3/',
  }),
  tagTypes: ['FavoriteMovies'],
  endpoints: (builder) => ({
    fetchPopularMovies: builder.query<Movie[], void>({
      query: () => ({
        url: 'discover/movie',
        params: {
          sort_by: 'popularity.desc',
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((movie) => {
          return {
            id: movie.id.toString(), // 🔁 convert number to string
            adult: movie.adult,
            poster_path: movie.poster_path,
            overview: movie.overview,
            release_date: movie.release_date,
            title: movie.original_title, // Adjusted to use original_title
            genres: movie.genre_ids,
          } as Movie;
        });
      },
      
    }),

    fetchHighestRatedMovies: builder.query<Movie[], void>({
      query: () => ({
        url: 'discover/movie',
        params: {
          sort_by: 'vote_average.desc',
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((movie) => {
          return {
            id: movie.id.toString(), // 🔁 convert number to string
            adult: movie.adult,
            poster_path: movie.poster_path,
            overview: movie.overview,
            release_date: movie.release_date,
            title: movie.original_title,
            genres: movie.genre_ids,
          } as Movie;
        });
      },
      
    }),

    fetchSearchMovie: builder.query<Movie[], { searchTerm: string }>({
      query: ({searchTerm}) => ({
        url: 'search/movie',
        params: {
          query: searchTerm,
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((movie) => {
          return {
            id: movie.id.toString(), // 🔁 convert number to string
            adult: movie.adult,
            poster_path: movie.poster_path,
            overview: movie.overview,
            release_date: movie.release_date,
            title: movie.original_title, // Adjusted to use original_title
            genres: movie.genre_ids,
          } as Movie;
        });
      },
      
    }),

    fetchUpcomingMovies: builder.query<Movie[], void>({
      query: () => ({
        url: 'movie/upcoming',
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((movie) => {
          return {
            id: movie.id.toString(), // 👈 Convert number to string
            adult: movie.adult,
            poster_path: movie.poster_path,
            overview: movie.overview,
            release_date: movie.release_date,
            title: movie.original_title,
            genres: movie.genre_ids,
            vote_average: movie.vote_average,
          } as Movie;
        });
      },
    }),
    fetchMovieTrailer: builder.query<{ id: string; key: string; site: string; type: string } | null, number>({
      query: (movieId) => ({
        url: `movie/${movieId}/videos`,
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: { id: string; key: string; site: string; type: string }[] }) => {
        const trailers = response.results.filter(video => video.type === 'Trailer' && video.site === 'YouTube');
        return trailers.length ? trailers[0] : null; 
      },
    }),
    getFavoriteMovies: builder.query<Movie[], void>({
      query: () => ({
        url: 'http://localhost:3000/Favorites',
      }),
      providesTags: ['FavoriteMovies'],
    }),

    addFavoriteMovie: builder.mutation<void, Movie>({
      query: (movie) => ({
        url: 'http://localhost:3000/Favorites',
        method: 'POST',
        body: {
          ...movie,
          id: movie.id, // Make sure to use the original ID
        },
      }),
      invalidatesTags: ['FavoriteMovies'],
    }),
    removeFavoriteMovie: builder.mutation<void, string>({
      query: (id) => ({
        url: `http://localhost:3000/Favorites/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: ['FavoriteMovies'],
    }),
    fetchPopularTVShows: builder.query<Movie[], void>({
      query: () => ({
        url: 'discover/tv',
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: MovieResults[] }) => {
        return response.results.map((tv) => ({
          id: tv.id.toString(), // 🔁 Convert to string
          adult: tv.adult,
          poster_path: tv.poster_path,
          overview: tv.overview,
          release_date: tv.first_air_date || '', // fallback if missing
          title: tv.name, // TV shows use `name`
          genres: tv.genre_ids,
          vote_average: tv.vote_average,
        } as Movie));
      }
    }),
    fetchMovieGenres: builder.query<{ id: number; name: string }[], void>({
      query: () => ({
        url: 'genre/movie/list',
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { genres: { id: number; name: string }[] }) => {
        return response.genres;
      },
    }),
    
    fetchTVGenres: builder.query<{ id: number; name: string }[], void>({
      query: () => ({
        url: 'genre/tv/list',
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
        },
        method: 'GET',
      }),
      transformResponse: (response: { genres: { id: number; name: string }[] }) => {
        return response.genres;
      },
    }),
    searchInstructor: builder.query<any[], { name: string }>({
      query: ({ name }) => ({
        url: 'search/person',
        params: {
          api_key: '81c50c197b83129dd4fc387ca6c8c323',
          query: name,
        },
        method: 'GET',
      }),
      transformResponse: (response: { results: any[] }) => {
        // Optional: filter only those with known works
        return response.results.filter((person) => person.known_for?.length > 0);
      },
    }),
  }),
});

export const {
  useFetchPopularMoviesQuery,
  useFetchHighestRatedMoviesQuery,
  useFetchSearchMovieQuery,
  useFetchUpcomingMoviesQuery,
  useFetchMovieTrailerQuery,
  useGetFavoriteMoviesQuery,
  useAddFavoriteMovieMutation,
  useRemoveFavoriteMovieMutation,
  useFetchPopularTVShowsQuery,
  useFetchMovieGenresQuery,
  useFetchTVGenresQuery,
  useSearchInstructorQuery,
} = moviesApi;

export { moviesApi };