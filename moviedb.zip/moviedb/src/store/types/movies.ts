// Interface for den enkelte film
export interface Movie {
    id: string;
    adult: boolean;
    poster_path: string;
    overview: string;
    release_date: string;
    string: string;
    title: string;
    genres: number[];
    vote_average: number;
  }

  // Interface for API-response
  export interface MovieResults {
    adult: boolean;
    backdrop_path: string;
    genre_ids: number[];
    poster_path: string;
    overview: string;
    release_date: string;
    id: number;
    original_language: string;
    original_title: string;
    vote_average: number;
    name: string; 
    first_air_date: string;
  }
